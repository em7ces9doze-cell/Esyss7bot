EM7 ULTIMATE — BOT FACTORY v5

Files:
- index.js       Main EM7 Discord bot
- bot-factory.js Project generator module
- package.json   Dependencies and start command

FadeHost environment variables (keep your existing values):
DISCORD_TOKEN
CLIENT_ID
GROQ_API_KEY
Optional:
GROQ_MODEL=openai/gpt-oss-120b
DEV_GUILD_ID

Deploy:
1. Replace index.js with the supplied index.js.
2. Upload bot-factory.js beside index.js.
3. Replace package.json.
4. Keep the existing environment variables in FadeHost. Never paste tokens into chat or source files.
5. Reinstall dependencies / run npm install, then restart.
6. In the EM7 private control room, say: "أنشئ بوت تكت باسم support-center".
   Or: "أنشئ بوت فعاليات باسم event-master".
7. Approve the project-generation card. EM7 sends a ZIP attachment in Discord.

Generated bot projects:
- ticket: /ticket-setup, private ticket channels, owner/staff access, close button, ticket stats.
- events: /event-create, RSVP join/leave buttons, /event-list, persistent JSON data.
- welcome: welcome embed on member join (requires Guild Members intent enabled in the Discord Developer Portal).

Important:
- The factory creates project files only. Each independent bot needs its own Discord application and bot token, created manually in Discord Developer Portal.
- Put each new bot token only in that bot's hosting environment as DISCORD_TOKEN. Never send it to EM7 or commit it to GitHub.
- Use least-privilege bot permissions; do not grant Administrator.
- Project update currently updates the supported template configuration and regenerates the ZIP. It does not yet rewrite arbitrary new features from natural-language code requests.

Validation performed:
- node --check index.js
- node --check bot-factory.js
- node --check generated ticket.js, events.js, welcome.js templates
No live Discord server or FadeHost deployment test was performed.
